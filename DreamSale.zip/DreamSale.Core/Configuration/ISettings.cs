﻿namespace DreamSale.Core.Configuration
{
    /// <summary>
    /// Setting interface
    /// </summary>
    public interface ISettings
    {
    }
}
