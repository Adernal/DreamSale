﻿namespace DreamSale.Core
{
    public static class DreamSaleVersion
    {
        /// <summary>
        /// Gets or sets the store version
        /// </summary>
        public static string CurrentVersion
        {
            get
            {
                return "1.0";
            }
        }
    }
}
