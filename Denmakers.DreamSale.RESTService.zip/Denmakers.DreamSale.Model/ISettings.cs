﻿namespace Denmakers.DreamSale.Model
{
    public interface ISettings
    {
    }
}
