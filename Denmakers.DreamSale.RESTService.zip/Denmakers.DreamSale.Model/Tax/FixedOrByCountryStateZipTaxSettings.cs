﻿namespace Denmakers.DreamSale.Model.Tax
{
    public class FixedOrByCountryStateZipTaxSettings : ISettings
    {
        public bool CountryStateZipEnabled { get; set; }
    }
}
