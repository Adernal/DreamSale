﻿
namespace Denmakers.DreamSale.Model.Customers 
{ 
    public enum PasswordFormat
    {
        Clear = 0,
        Hashed = 1,
        Encrypted = 2
    }
}
