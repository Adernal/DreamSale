﻿namespace Denmakers.DreamSale.Data.Infrastructure
{
    public interface IUnitOfWork
    {
        void Commit();
    }
}
